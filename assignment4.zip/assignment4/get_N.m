function N = get_N(T, f, Wave, Env)
    N = Note(2, 11, T, f, Wave, Env);
end