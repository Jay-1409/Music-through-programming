function G = get_G(T, f, Wave, Env)
    G = Note(2, 4, T, f, Wave, Env);
end