function St = get_St(T, f, Wave, Env)
    St = Note(3, 0, T, f, Wave, Env);
end