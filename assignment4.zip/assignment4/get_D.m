function D = get_D(T, f, Wave, Env)
    D = Note(2, 9, T, f, Wave, Env);
end
