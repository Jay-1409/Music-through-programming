function M = get_M(T, f, Wave, Env)
    M = Note(2, 6, T, f, Wave, Env);
end