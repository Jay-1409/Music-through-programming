function S = get_S(T, f, Wave, Env)
    S = Note(2, 0, T, f, Wave, Env);
end