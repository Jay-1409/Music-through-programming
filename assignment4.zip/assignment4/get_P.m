function P = get_P(T, f, Wave, Env)
    P = Note(2, 7, T, f, Wave, Env);
end