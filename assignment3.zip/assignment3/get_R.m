function R = get_R(T2, f, Wave, Env)
    R = Note(2, 2, T2, f, Wave, Env);
end