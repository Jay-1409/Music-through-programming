function S = waveSine(t, f1)
    S = sin(2 * pi * f1 * t);
end
